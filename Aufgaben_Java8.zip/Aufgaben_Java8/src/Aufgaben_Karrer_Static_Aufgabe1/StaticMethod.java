/* Aufgabe:
 * Kann die statische Methode �ber eine nicht-statische Referenz aufgerufen werden?
 * Kann die statische Methode �berhaupt �ber eine implementierende Klasse aufgerufen werden?
 */

package Aufgaben_Karrer_Static_Aufgabe1;

import java.math.BigDecimal;


public class StaticMethod{
	
	public static void main(String[] args) {
		//todo
	}	
}

interface Gehaltsmodell
{
	BigDecimal MAX_GEHALT = new BigDecimal(1_000_000);
	
	static boolean isValidGehalt( BigDecimal gehalt ) {
	    return gehalt.compareTo(BigDecimal.ONE) > 0 && gehalt.compareTo(MAX_GEHALT) < 0;
	  }
	
	BigDecimal getGehalt();
}


class FixGehalt implements Gehaltsmodell{
	
	private BigDecimal gehalt;
	
	public FixGehalt(BigDecimal gehalt) {
		super();
		this.gehalt = gehalt;
	}

	@Override
	public BigDecimal getGehalt() {
		return gehalt;
	}
	
}


