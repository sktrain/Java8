package Aufgaben_3_8;

import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Aufgabe_2 {

	public static void main(String[] args) {

		final Predicate<Integer> isEven = null; // ... TODO ...
				
		final Predicate<Integer> isNull = null; // ... TODO ...
				
		final IntPredicate isPositive = null; // ... TODO ...

	}

}
