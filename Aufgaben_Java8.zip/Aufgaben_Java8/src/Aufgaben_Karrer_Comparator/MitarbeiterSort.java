package Aufgaben_Karrer_Comparator;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MitarbeiterSort {

	public static void main(String[] args) {
		
		List<Mitarbeiter> mlist = getMitarbeiter(20);

		//Aufgabe 1a: nach nat�rlicher Ordnung sortieren
		
		// Jetzt nach Geh�ltern sortiert (natural order)
		
		
		//Aufgabe 1b: nach Geh�ltern (nat�rliche Ordnung) absteigend sortieren
		
		
				
		//Aufgabe 2a: nach Vornamen und anschlie�end nach Nachnamen sortieren
		
		
		//Aufgabe 2b: geht das auch "kompakter" mit Hilfe der statischen Methoden aus Comparator
		
		
		
		//Aufgabe 2c: funktionieren die Comparatoren aus 2b auch f�r eine reine List<Arbeiter>
		
		List<Arbeiter> alist = getArbeiter(20);
				
		
		//Aufgabe 3a: nach Einstellungsdatum, Geburtsdatum und Gehalt (in dieser Reihenfolge) sortieren
		// (zus�tzlich auch mit Hilfe der statischen keyExtractor-Methoden)
		
		
		
		
		//Aufgabe 3b: was ist wenn null-Referenzen in den zu sortierenden Werten auftreten, z.B. Einstellungsdatum und/oder Gehalt ist null?
		//Ist das Verhalten bei Nachsortierung identisch?
		
		

		
		//Aufgabe 3c: Wie l�sst sich das Null-Handling beim Sortieren explizit festlegen (nulls first oder nulls last)?
		
		
	}

	

	private static List<Mitarbeiter> getMitarbeiter(int size) {

		List<Mitarbeiter> mlist = new ArrayList<Mitarbeiter>();

		Mitarbeiter m;
		for (int i = 0; i < size; ++i) {
			if (i % 2 == 0) {
				m = new FixGehaltMitarbeiter(i, "Max", "Maulwurf" + i,
						LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000 + (int) (Math.random() * 21), 1 + (int) (Math.random() * 12), 1),
						Geschlecht.M, new BigDecimal((int) (Math.random() * 10000)));
				mlist.add(m);
			} else {
				m = new Arbeiter(i, "Erika", "Musterfrau" + i, LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000 + (int) (Math.random() * 21), 1 + (int) (Math.random() * 12), 1),
						Geschlecht.W, new BigDecimal((int) (Math.random() * 100)), new BigDecimal(120));
				mlist.add(m);
			}
		}
		return mlist;
	}
	
	private static List<Arbeiter> getArbeiter(int size) {

		List<Arbeiter> mlist = new ArrayList<Arbeiter>();

		Arbeiter m;
		for (int i = 0; i < size; ++i) {
			m = new Arbeiter(i, "Erika", "Musterfrau" + i, LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000 + (int) (Math.random() * 21), 1 + (int) (Math.random() * 12), 1),
						Geschlecht.W, new BigDecimal((int) (Math.random() * 100)), new BigDecimal(120));
				mlist.add(m);
			}
		return mlist;
	}

}
