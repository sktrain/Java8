package Aufgaben_Karrer_Comparator;

public enum Geschlecht { W, M, D

}
