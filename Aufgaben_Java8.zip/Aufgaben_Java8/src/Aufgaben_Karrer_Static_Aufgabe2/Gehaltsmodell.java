/* Aufgabe: Realisieren des Factory-Method-Patterns via statischer Interface-Methode
 * Zu Gehaltsmodell existieren bereits 2 Implementierungen, die z.B. via Zeichenkette
 * "A" f�r Arbeitermodell bzw. "F" f�r FixGehaltmodell ausgew�hlt werden k�nnen.
 * Man kann mit selbstgew�hlten Werten f�r die Attribute arbeiten oder (zus�tzlicher Schritt) die Werte
 * aus der Properties-Datei "factory.properties" einlesen
 */

//sample code f�r Properties
//Path path = Paths.get( "factory.properties" );
//		Properties prop2 = new Properties();
//		try ( Reader reader = Files.newBufferedReader( path, StandardCharsets.ISO_8859_1 ) ) {
//		    prop2.load( reader );
//		  }	

package Aufgaben_Karrer_Static_Aufgabe2;

import java.io.Serializable;
import java.math.BigDecimal;

public interface Gehaltsmodell extends Serializable {
	
	public abstract BigDecimal getGehalt();
	
	//todo

}
