package Aufgaben_Karrer_Lambdas.Aufgabe3;

public class Application {

	public static void main(String[] args) {
		new MathFrame();
	}
	
}
