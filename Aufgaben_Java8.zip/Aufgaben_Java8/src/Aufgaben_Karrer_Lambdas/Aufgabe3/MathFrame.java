/* Aufgabe:
 * Der Code f�r die Methode onPlus und onMinus ist ziemlich �hnlich. 
 * Statt der beiden Methoden kann eine Methode onCalc verwendet werden, der die jeweilige
 * Rechenoperation als Baustein vom Typ IntBinaryOperator �bergeben wird.
 */

package Aufgaben_Karrer_Lambdas.Aufgabe3;

import java.awt.FlowLayout;
import java.util.function.IntBinaryOperator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class MathFrame extends JFrame {

	private final JTextField textFieldX = new JTextField(10);
	private final JTextField textFieldY = new JTextField(10);
	private final JButton buttonPlus = new JButton("Plus");
	private final JButton buttonMinus = new JButton("Minus");
	private final JTextField textFieldResult = new JTextField(10);

	public MathFrame() {
		this.setLayout(new FlowLayout());
		this.add(this.textFieldX);
		this.add(this.textFieldY);
		this.add(this.buttonPlus);
		this.add(this.buttonMinus);
		this.add(this.textFieldResult);
		this.registerListeners();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
		this.setVisible(true);
	}
	
	
	//todo
	private void registerListeners() {
				
	}


    
}
