/* Aufgabe:
 * Umstellung des Codes auf Lambdas
 * Kann die InterruptedException weitergereicht, sprich geworfen, werden?
 * 
 * Zusatzaufgabe (anspruchsvoll):
 * kann mit den neuen Sprachmitteln ein generelles Exception-Wrapping von Checked auf Unchecked realisiert werden?
 * Tip: Funktionales Interface f�r das Wrapping mit statischer Utility-Methode zur Ausf�hrung
 */

package Aufgaben_Karrer_Lambdas.Aufgabe1;

public class ThreadWithException {

	public static void main(String[] args) {
		Runnable r = new CountingRunnable();
		Thread t = new Thread(r);
		t.start();
		try {
			t.join();
		}
		catch (InterruptedException e) {
		}
	}
}

class CountingRunnable implements Runnable {
	public void run() {
		for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(1000);
				System.out.print(i + " ");
			}
			catch (InterruptedException e) {
			}
		}
	}
}
