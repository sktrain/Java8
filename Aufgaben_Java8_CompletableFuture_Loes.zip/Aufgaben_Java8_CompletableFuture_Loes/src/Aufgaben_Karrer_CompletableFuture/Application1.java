package Aufgaben_Karrer_CompletableFuture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

public class Application1 {

	public static void main(String[] args) throws Exception {
				
		System.out.println(aufgabe1(8.0, 6.0));
		
		System.out.println(aufgabe2());
		
		
	}

	//Satz des Pythagoras (Verwendung von double):  c = Wurzel(a*a + b*b)
	private static double aufgabe1(double a, double b) throws InterruptedException, ExecutionException {
		
		CompletableFuture<Double> kathete1 = CompletableFuture.supplyAsync(() -> a)
											 .thenApply(k1 -> k1 * k1);
				                            
		
		CompletableFuture<Double> kathete2 = CompletableFuture.supplyAsync(() -> b)
				 							 .thenApply(k2 -> k2 * k2)
                							 .thenCombine(kathete1, (quadrat1 , quadrat2) -> Math.sqrt(quadrat1 + quadrat2));
                							 //.thenAccept(System.out::println);
                							
                							 
		// damit ist das Netz von Rechenschritten aufgebaut		
		// jetzt Verarbeitung anstossen (pull-Modell via get des Future)
		
		
		double c = kathete2.get();		
		return c;
	
	}
	

	//Aufgabe auf Basis int bzw. Integer:  (a + 1) * (b + 2) * (c + 3) 
	private static int aufgabe2() throws InterruptedException, ExecutionException {
				
		//der Compiler erlaubt nicht das direkte Verketten des Konstruktors mit der nachfolgenden Methode!
		CompletableFuture<Integer> fa = new CompletableFuture<>();
		                           fa.thenApplyAsync(a -> a+1);
				                       
		CompletableFuture<Integer> fb = new CompletableFuture<>(); 
										fb.thenApplyAsync(b -> b + 2)
										.thenCombine(fa, (x , y) -> x * y);
		
		CompletableFuture<Integer> fc = new CompletableFuture<>();
					   
		
		//damit ist das Rechenschritt-Netz aufgebaut

		
		//jetzt die Berechnung ansto�en 
		fa.complete(1);
		fb.complete(2);
		fc.complete(3);
		Integer v = fc.thenApplyAsync(c -> c + 3)
				.thenCombine(fb, (x , y) -> x * y).get();
		return v;
	}
	
}
