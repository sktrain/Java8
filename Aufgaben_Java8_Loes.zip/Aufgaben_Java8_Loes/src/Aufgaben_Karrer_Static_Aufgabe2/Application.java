package Aufgaben_Karrer_Static_Aufgabe2;

import java.io.IOException;

public class Application {

	public static void main(String[] args) throws IllegalArgumentException, IOException {
		System.out.println(Gehaltsmodell.getGehaltsmodell("A"));
		System.out.println(Gehaltsmodell.getGehaltsmodell("F"));
	}

}
