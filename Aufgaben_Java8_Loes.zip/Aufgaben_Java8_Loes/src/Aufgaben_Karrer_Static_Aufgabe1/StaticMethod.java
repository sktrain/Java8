/* Aufgabe:
 * Kann die statische Methode �ber eine nicht-statische Referenz aufgerufen werden?
 * Kann die statische Methode �berhaupt �ber eine implementierende Klasse aufgerufen werden?
 */

package Aufgaben_Karrer_Static_Aufgabe1;

import java.math.BigDecimal;


public class StaticMethod{
	
	public static void main(String[] args) {
		Gehaltsmodell gm = new FixGehalt(new BigDecimal(5000));
		BigDecimal gehalt = gm.getGehalt();
		//Verwendung nicht-statischer Referenz ist nicht m�glich (anders als bei Klassen)		
		//gm.isValidGehalt(gehalt);
		System.out.println(Gehaltsmodell.isValidGehalt(gehalt));
		
		//Verwendung statischer Referenz via implementierender Klasse ist auch nicht m�glich
		//FixGehalt.isValidGehalt(gehalt);
		//aber sehr wohl Zugriff auf die stische Konstante
		System.out.println(FixGehalt.MAX_GEHALT);
	}	
}

interface Gehaltsmodell
{
	BigDecimal MAX_GEHALT = new BigDecimal(1_000_000);
	
	static boolean isValidGehalt( BigDecimal gehalt ) {
	    return gehalt.compareTo(BigDecimal.ONE) > 0 && gehalt.compareTo(MAX_GEHALT) < 0;
	  }
	
	BigDecimal getGehalt();
}


class FixGehalt implements Gehaltsmodell{
	
	private BigDecimal gehalt;
	
	public FixGehalt(BigDecimal gehalt) {
		super();
		//auch hier ist der Aufruf nur anhand des Interface m�glich
		if (Gehaltsmodell.isValidGehalt(gehalt))
		this.gehalt = gehalt;
	}

	@Override
	public BigDecimal getGehalt() {
		return gehalt;
	}
	
}


