package Aufgaben_Karrer_Comparator;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MitarbeiterSort {

	public static void main(String[] args) {

		//Aufgabe 1a: nach nat�rlicher Ordnung sortieren
		//vorher
		List<Mitarbeiter> mlist = getMitarbeiter(20);
		System.out.println("\n**** Ausgabe in F�llreihenfolge, da Listen und Arrays die Ordnung beibehalten*****\n");
		mlist.forEach(System.out::println);

		// Jetzt nach Geh�ltern sortiert (natural order)
		System.out.println("\n***********Hier nach Gehalt sortiert**************\n");
		//Collections.sort(mlist);
		//alternativ
		Collections.sort(mlist, Comparator.naturalOrder());
		mlist.forEach(System.out::println);
		
		
		
		//Aufgabe 1b: nach Geh�ltern (nat�rliche Ordnung) absteigend sortieren
		//vorher
		mlist = getMitarbeiter(20);
		System.out.println("\n**** Ausgabe in F�llreihenfolge, da Listen und Arrays die Ordnung beibehalten*****\n");
		mlist.forEach(System.out::println);
		
		System.out.println("\n***********Hier nach Gehalt absteigend sortiert**************\n");
		Comparator<Mitarbeiter> cnatural = Comparator.naturalOrder();
		Collections.sort(mlist, cnatural.reversed());
		//der Compiler erlaubt nicht:
		//Collections.sort(mlist, Comparator.naturalOrder().reversed());
		mlist.forEach(System.out::println);

		
		//Aufgabe 2a: nach Vornamen und anschlie�end nach Nachnamen sortieren
		//vorher
				mlist = getMitarbeiter(20);
				System.out.println("\n**** Ausgabe in F�llreihenfolge, da Listen und Arrays die Ordnung beibehalten*****\n");
				mlist.forEach(System.out::println);
		
				System.out.println("\n***********Hier nach Vornamen und Nachnamen sortiert**************\n");
		//der Compiler erlaubt in der Regel nicht, direkt auf einen Lamda-Ausdruck den .-Operator anzuwenden
		Comparator<Mitarbeiter> cnachn = (Mitarbeiter m1, Mitarbeiter m2) -> m1.getVorname().compareTo(m2.getVorname());
		Collections.sort(mlist, cnachn.thenComparing((Mitarbeiter m1, Mitarbeiter m2) -> m1.getNachname().compareTo(m2.getNachname())));
		mlist.forEach(System.out::println);
		
		//Aufgabe 2b: geht das auch "kompakter" mit Hilfe der statischen Methoden aus Comparator
		//vorher
		mlist = getMitarbeiter(20);
		System.out.println("\n**** Ausgabe in F�llreihenfolge, da Listen und Arrays die Ordnung beibehalten*****\n");
		mlist.forEach(System.out::println);

		System.out.println("\n***********Hier nach Vornamen und Nachnamen mit statischen Methoden sortiert**************\n");
		Collections.sort(mlist, Comparator.comparing((Mitarbeiter m) -> m.getVorname()).thenComparing(Comparator.comparing(Mitarbeiter::getNachname)));
		mlist.forEach(System.out::println);
		
		
		//Aufgabe 2c: funktionieren die Comparatoren aus 2b auch f�r eine reine List<Arbeiter>
		//vorher
		List<Arbeiter> alist = getArbeiter(20);
				System.out.println("\n**** Ausgabe in F�llreihenfolge, da Listen und Arrays die Ordnung beibehalten*****\n");
				alist.forEach(System.out::println);
				
				System.out.println("\n***********auch f�r Arbeiter-Liste **************\n");
		Collections.sort(alist, Comparator.comparing((Mitarbeiter m) -> m.getVorname()).thenComparing(Comparator.comparing(Mitarbeiter::getNachname)));
		alist.forEach(System.out::println);

		
		//Aufgabe 3a: nach Einstellungsdatum, Geburtsdatum und Gehalt (in dieser Reihenfolge) sortieren
		//vorher
		mlist = getMitarbeiter(20);
		System.out.println("\n**** Ausgabe in F�llreihenfolge, da Listen und Arrays die Ordnung beibehalten*****\n");
		mlist.forEach(System.out::println);
		
		System.out.println("\n******Hier nach Einstellungsdatum, Geburtsdatum und Gehalt sortiert************\n");
		Comparator<Mitarbeiter> ceinstdatum = (Mitarbeiter m12, Mitarbeiter m21) -> m12.getEinstdatum().compareTo(m21.getEinstdatum());
		Comparator<Mitarbeiter> cgebdatum = (Mitarbeiter m13, Mitarbeiter m23) -> m13.getGebdatum().compareTo(m23.getGebdatum());
		Comparator<Mitarbeiter> cgehalt = (Mitarbeiter m11, Mitarbeiter m22) -> m11.getGehalt().compareTo(m22.getGehalt());
		Collections.sort(mlist, ceinstdatum.thenComparing(cgebdatum).thenComparing(cgehalt));
		mlist.forEach(System.out::println);
		
		// oder mit Hilfe der statischen keyExtractor-Methoden
		Collections.sort(mlist, Comparator.comparing(Mitarbeiter::getEinstdatum)
						 .thenComparing(Comparator.comparing(Mitarbeiter::getGebdatum))
						 .thenComparing(Comparator.comparing(Mitarbeiter::getGehalt)));
		mlist.forEach(System.out::println);
		
		
		
		//Aufgabe 3b: was ist wenn null-Referenzen in den zu sortierenden Werten auftreten, z.B. Einstellungsdatum und/oder Gehalt ist null?
		//Ist das Verhalten bei Nachsortierung identisch?
		mlist = getMitarbeiter(20);	
		System.out.println("\n****** was ist wenn null-Referenzen in den zu sortierenden Werten auftreten ************\n");
		FixGehaltMitarbeiter uschi = new FixGehaltMitarbeiter(100, "Uschi", "Meier", LocalDate.of(2000, 1, 1),null, Geschlecht.W, null);
		mlist.add(uschi);
		try {
			Collections.sort(mlist, Comparator.comparing(Mitarbeiter::getEinstdatum)
					 .thenComparing(Comparator.comparing(Mitarbeiter::getGebdatum))
					 .thenComparing(Comparator.comparing(Mitarbeiter::getGehalt)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		mlist.forEach(System.out::println);		
		
		//das Verhalten ist beim Nachsortieren identisch, sofern �berhaupt nachsortiert wird!
		//deshalb Einf�gen eines weiteren Mitarbeiters mit gleichen Werten in den Hauptkriterien
		mlist = getMitarbeiter(20);
		FixGehaltMitarbeiter uschi1 = new FixGehaltMitarbeiter(100, "Uschi", "Meier", LocalDate.of(2000, 1, 1), LocalDate.of(2020, 1, 1), Geschlecht.W, null);
		mlist.add(uschi1);
		FixGehaltMitarbeiter karl = new FixGehaltMitarbeiter(100, "Karl", "Meier", LocalDate.of(2000, 1, 1), LocalDate.of(2020, 1, 1), Geschlecht.W, null);
		mlist.add(karl);
		try {
			Collections.sort(mlist, ceinstdatum
					.thenComparing(cgebdatum)
					.thenComparing(cgehalt));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		mlist.forEach(System.out::println);

		
		//Aufgabe 3c: Wie l�sst sich das Null-Handling beim Sortieren explizit festlegen (nulls first oder nulls last)?
		mlist = getMitarbeiter(20);
		FixGehaltMitarbeiter uschi2 = new FixGehaltMitarbeiter(100, "Uschi", "Meier", LocalDate.of(2020, 1, 1), null, Geschlecht.W, null);
		mlist.add(uschi2);
		FixGehaltMitarbeiter karl2 = new FixGehaltMitarbeiter(100, "Karl", "Meier", LocalDate.of(2020, 1, 1), LocalDate.of(2020, 1, 1), Geschlecht.W, null);
		mlist.add(karl2);
		FixGehaltMitarbeiter karl3 = new FixGehaltMitarbeiter(100, "Karl", "Meier", LocalDate.of(2020, 1, 1), LocalDate.of(2020, 1, 1), Geschlecht.W, BigDecimal.TEN);
		mlist.add(karl3);
		System.out.println("\n****** Sortieren mit Null-Handling  ************\n");
		Collections.sort(mlist, Comparator.comparing(Mitarbeiter::getEinstdatum, Comparator.nullsFirst(LocalDate::compareTo))
		 .thenComparing(Comparator.comparing(Mitarbeiter::getGebdatum, Comparator.nullsFirst(LocalDate::compareTo)))
		 .thenComparing(Comparator.comparing(Mitarbeiter::getGehalt, Comparator.nullsLast(BigDecimal::compareTo)))
				);
		mlist.forEach(System.out::println);
		
	}

	

	private static List<Mitarbeiter> getMitarbeiter(int size) {

		List<Mitarbeiter> mlist = new ArrayList<Mitarbeiter>();

		Mitarbeiter m;
		for (int i = 0; i < size; ++i) {
			if (i % 2 == 0) {
				m = new FixGehaltMitarbeiter(i, "Max", "Maulwurf" + i,
						LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000 + (int) (Math.random() * 21), 1 + (int) (Math.random() * 12), 1),
						Geschlecht.M, new BigDecimal((int) (Math.random() * 10000)));
				mlist.add(m);
			} else {
				m = new Arbeiter(i, "Erika", "Musterfrau" + i, LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000 + (int) (Math.random() * 21), 1 + (int) (Math.random() * 12), 1),
						Geschlecht.W, new BigDecimal((int) (Math.random() * 100)), new BigDecimal(120));
				mlist.add(m);
			}
		}
		return mlist;
	}
	
	private static List<Arbeiter> getArbeiter(int size) {

		List<Arbeiter> mlist = new ArrayList<Arbeiter>();

		Arbeiter m;
		for (int i = 0; i < size; ++i) {
			m = new Arbeiter(i, "Erika", "Musterfrau" + i, LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000 + (int) (Math.random() * 21), 1 + (int) (Math.random() * 12), 1),
						Geschlecht.W, new BigDecimal((int) (Math.random() * 100)), new BigDecimal(120));
				mlist.add(m);
			}
		return mlist;
	}

}
