package Aufgaben_Karrer_Lambdas.Aufgabe2;

public class Application {

	public static void main(String[] args) {
		new MathFrame();
	}
	
}
