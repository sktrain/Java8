package Aufgaben_Karrer_Lambdas.Aufgabe4;

public class Application {

	public static void main(String[] args) {
		
		//new MathFrame_Map();
		
		new MathFrame_Enum();		
		
	}
	
}
