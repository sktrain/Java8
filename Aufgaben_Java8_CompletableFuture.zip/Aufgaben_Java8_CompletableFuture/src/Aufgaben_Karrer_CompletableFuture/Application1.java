package Aufgaben_Karrer_CompletableFuture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Application1 {

	public static void main(String[] args) throws Exception {
				
		System.out.println(aufgabe1(8.0, 6.0));
		
		System.out.println(aufgabe2());
		
		
	}

	//Satz des Pythagoras (Verwendung von double):  c = Wurzel(a*a + b*b)
	private static double aufgabe1(double a, double b) {
		
		//todo
		
		return 0;
	}
	

	//Aufgabe auf Basis int bzw. Integer:  (a + 1) * (b + 2) * (c + 3) 
	private static int aufgabe2() {
				
		//todo
		
		return 0;
	}
	
}
