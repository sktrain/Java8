/* Verwendung eines Standard-Collectors */

package Aufgaben_Karrer_Streams.Aufgabe2;

import java.util.stream.Stream;

public class PosNegCounter {

	public static void main(String[] args) {

         Stream<Integer> is = Stream.of(-1, 3, 5, 0, -4, 7, 0, 8);
         
         

	}

}
