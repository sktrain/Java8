/* Berechnung des Produkts der positiven Ganzzahlen von 1 bis 100 (Fakult�t)
 * und der Summe dieser Zahlen in einem Stream-Durchlauf mittels eigenem Reducer
*/

package Aufgaben_Karrer_Streams.Aufgabe3;

import java.util.stream.IntStream;

public class Reduce_Sum_Fak {

	public static void main(String[] args) {

		IntStream is = IntStream.range(1, 100);
		
	}
}

