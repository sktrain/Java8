package Aufgaben_Karrer_Streams.Aufgabe1;

public enum Geschlecht { W, M, D

}
