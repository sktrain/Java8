package chapter3_streams.collectors;

import static java.util.stream.Collectors.joining;

import java.util.Arrays;
import java.util.stream.Stream;

/**
 * Beispielprogramm zeigt verschiedene Verkettungen mit joining().
 * 
 * @author Michael Inden
 * 
 * Copyright 2015 by Michael Inden 
 */
public class CollectorsJoiningExample
{
    public static void main(final String[] args)
    {
        final String[] words = { "This", "Is", "The", "Joining", "Collector" };
    
        // 3 Varianten der Kombination
        System.out.println(Arrays.stream(words).collect(joining()));
        System.out.println(Arrays.stream(words).collect(joining(" | ")));
        System.out.println(Arrays.stream(words).collect(joining(", ", "[", "]")));
    
        final Stream<String> names = Stream.of("Andy", "Dirk", "Merten");
        final String prefix = "Many thanks to ";
        final String postfix = " for your comments!";    
        System.out.println(names.collect(joining(", ", prefix, postfix)));
    }
}
