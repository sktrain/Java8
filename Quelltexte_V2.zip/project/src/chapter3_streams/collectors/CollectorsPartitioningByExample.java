package chapter3_streams.collectors;

import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.partitioningBy;

import java.util.List;
import java.util.TreeSet;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import chapter3_streams.Gender;
import chapter3_streams.Person;

/**
 * Beispielprogramm zeigt verschiedene Varianten der Partionierung mit partitioningBy().
 * 
 * @author Michael Inden
 * 
 * Copyright 2015 by Michael Inden 
 */
public class CollectorsPartitioningByExample
{
    public static void main(final String[] args)
    {
        final List<Person> persons = CollectorsToMapExample2.createPersons();
    
        final Predicate<Person> isFemale = person -> person.getGender() == Gender.FEMALE;
    
        System.out.println("Males and females in map");
        System.out.println(persons.stream().collect(partitioningBy(isFemale)));
    
        System.out.println("\nmap to just names");
        System.out.println(persons.stream().collect(partitioningBy(isFemale, 
                                            mapping(Person::getName, Collectors.toList()))));
    
        System.out.println("\nmap to unique cities");
        System.out.println(persons.stream().collect(partitioningBy(isFemale, 
                                                                   mapping(Person::getCity, Collectors.toSet()))));
    
        System.out.println("\nmap to unique cities sorted");
        System.out.println(persons.stream().collect(partitioningBy(isFemale, 
                                            mapping(Person::getCity, Collectors.toCollection(TreeSet::new)))));
    }
}
