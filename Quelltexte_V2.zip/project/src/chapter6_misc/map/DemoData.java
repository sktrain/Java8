package chapter6_misc.map;

import java.util.Arrays;
import java.util.List;

public class DemoData
{
    public static List<String> createDemoData()
    {
        final List<String> wordList = Arrays.asList("Dies", "ist", "eine", "Liste", "eine", "Liste", "kann", "Worte",
                                                    "enthalten", "Dies", "ist", "das", "Ende", "der", "Liste");
        return wordList;
    }
}